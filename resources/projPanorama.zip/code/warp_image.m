% Automated Panorama Stitching stencil code
% CS 129 Computational Photography, Brown U.
%
% Warps an img according to projective transfomation T

function [ im1, im2 ] = warp_image(A, B, T)
    
    % Your code here

    % Placeholder code
    im1 = A;
    im2 = B;

end